from django.apps import AppConfig


class DjangoRestAuthConfig(AppConfig):
    name = 'django_rest_auth'
