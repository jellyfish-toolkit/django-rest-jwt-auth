from django.apps import AppConfig


class DjangoRestJwtAuthConfig(AppConfig):
    name = 'django_rest_jwt_auth'
